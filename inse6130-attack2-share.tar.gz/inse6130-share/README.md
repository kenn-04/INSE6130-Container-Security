# INSE 6130 - Attack 2
## Docker Authorization Lab - OPA Baseline

This folder contains the Docker and OPA configuration prepared for the Attack 2 work on CVE-2024-41110.

### Environment
- Debian GNU/Linux 12
- Docker 20.10.24
- OPA Docker authorization plugin v0.9

### Files
- daemon.json: Docker authorization plugin configuration.
- policies/authz.rego: Initial OPA authorization policy.
- docker-version.txt: Docker version information.
- docker-security-version.txt: Debian package security status.
- docker-info.txt: Docker environment information.
- tests/test_policy.py: Simplified Python policy model.
- tests/test-results.md: Test results and limitations.

### Important notes
The OPA plugin is installed separately in the original VM. This archive contains its configuration and policy, not the plugin binary itself.

The installed Debian Docker package includes the security fix for CVE-2024-41110.

The Python tests are a simplified policy model. They do not reproduce the CVE or execute OPA.

This is the baseline configuration for the Attack 2 work. It is not the complete group project.
