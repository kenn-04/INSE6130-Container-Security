package docker.authz

default allow = false

# Autorise tout SAUF la création de conteneurs privilégiés
allow {
    not privileged_container
}

privileged_container {
    input.Body.HostConfig.Privileged == true
}
