def current_policy(body):
    try:
        privileged = body["HostConfig"]["Privileged"] is True
    except (KeyError, TypeError):
        privileged = False

    return not privileged


def hardened_policy(body):
    try:
        return body["HostConfig"]["Privileged"] is False
    except (KeyError, TypeError):
        return False


scenarios = [
    ("Non-privileged container", {"HostConfig": {"Privileged": False}}),
    ("Privileged container", {"HostConfig": {"Privileged": True}}),
    ("Missing Privileged field", {"HostConfig": {}}),
    ("Missing request body", None),
]

print("POLICY TEST RESULTS")
print("-" * 55)

for name, body in scenarios:
    current = "ALLOW" if current_policy(body) else "DENY"
    hardened = "ALLOW" if hardened_policy(body) else "DENY"

    print(f"\nScenario: {name}")
    print(f"Current policy:  {current}")
    print(f"Hardened policy: {hardened}")
