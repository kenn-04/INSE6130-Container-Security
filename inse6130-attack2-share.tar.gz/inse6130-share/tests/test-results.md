# Authorization Policy Tests

## Objective
Compare the current authorization logic with a stricter policy.

## Test scenarios

| Scenario | Current policy | Hardened policy |
|---|---|---|
| Privileged = false | ALLOW | ALLOW |
| Privileged = true | DENY | DENY |
| Privileged field missing | ALLOW | DENY |
| Request body missing | ALLOW | DENY |

## Observation
The current policy allows requests when the privileged field is missing.
The hardened policy only allows requests when Privileged is explicitly false.

## Limitation
These tests use a Python model of the policy logic.
They do not execute OPA or reproduce CVE-2024-41110.
